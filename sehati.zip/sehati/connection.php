<?php

    $database= new mysqli("sehati.ilkomerz.biz.id","root","","linksphe_sehati");
    if ($database->connect_error){
        die("Connection failed:  ".$database->connect_error);
    }

?>